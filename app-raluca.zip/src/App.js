import React, { Component } from "react";
import HeaderComponent from "../src/components/headerComponent/headerComponent";
import MainComponent from "../src/components/mainComponent/mainComponent";
import AxiosAPICall from "./services/APICalls";

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      items: [],
      showAddItemForm: false
    };
    this.url = "http://localhost:3000/todo/";
  }

  componentDidMount() {
    AxiosAPICall.getAllCall(this.url)
      .then(res => {
        this.setState({ items: res.data });
        //console.log(this.state.items);
      })
      .catch(error => {
        console.log(error);
      });
  }

  handleDeleteItem = itemId => {
    console.log(itemId);
    AxiosAPICall.deleteCall(this.url + itemId)
      .then(res => {
        console.log(res);
        const items = this.state.items.filter(i => i._id !== itemId);
        this.setState({ items });
      })
      .catch(error => {
        console.log(error);
        alert(error);
      });
  };

  handleAddItem = () => {
    this.setState({ showAddItemForm: !this.state.showAddItemForm });
    return (
      <div className="item-container">
        <form onSubmit={this.onSubmit}>
          <div className="form-group">
            <label>Add description</label>
            <input
              type="text"
              value="jfgh"
              onChange={this.onDescrpitionChange}
              className="form-control"
            />
          </div>
          <input type="submit" value="Add ToDo" className="btn btn-success btn-block" />
        </form>
      </div>
    );
    
    //console.log("Add btn clicked");
  };

  render() {
    return (
      <React.Fragment>
        <HeaderComponent />
        <MainComponent
          items={this.state.items}
          onDeleteItem={this.handleDeleteItem}
          onAddItem={this.handleAddItem}
          showForm={this.state.showAddItemForm}
        />
       {/*  {this.state.showAddItemForm ? (
          <div className="item-container">
          <form onSubmit={this.onSubmit}>
            <div className="form-group">
              <label>Add description</label>
              <input
                type="text"
                value="jfgh"
                onChange={this.onDescrpitionChange}
                className="form-control"
              />
            </div>
            <input type="submit" value="Add ToDo" className="btn btn-success btn-block" />
          </form>
        </div>
        ) : (
          " "
        )} */}
      </React.Fragment>
    );
  }
}

export default App;
