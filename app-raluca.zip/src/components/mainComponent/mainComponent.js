import React, { Component } from "react";
import AddButton from "../addBtnComponent/addButton";
import ItemsComponent from "../itemsComponent/itemsComponent";

class MainComponent extends Component {
  render() {
    return (
      <div className="main-container">
        <AddButton onAddItem={this.props.onAddItem} />
        <ItemsComponent
          items={this.props.items}
          onDeleteItem={this.props.onDeleteItem}
        ></ItemsComponent>
      </div>
    );
  }
}

export default MainComponent;
