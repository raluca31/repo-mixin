import React, { Component } from "react";

class AddButton extends Component {
  render() {
    return (
      <div className="button-container">
        <button className="btn-add btn btn-dark btn-sm" onClick={this.props.onAddItem}>Add</button>
      </div>
    );
  }
}

export default AddButton;
