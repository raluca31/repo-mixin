import React from "react";

const HeaderComponent = props => {
  return (
    <div className="header-container">
      <h1>HEADER</h1>
    </div>
  );
};

export default HeaderComponent;
