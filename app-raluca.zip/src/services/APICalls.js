import axios from "axios";

const AxiosAPICall = {
  postCall: function(url, val) {
    return axios.post(url, val);
  },
  getAllCall: function(url) {
    return axios.get(url);
  },
  deleteCall: function(url, val){
      return axios.delete(url,val);
  }

};

export default AxiosAPICall;
